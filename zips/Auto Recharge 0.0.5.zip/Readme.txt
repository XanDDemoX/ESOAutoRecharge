ESOAutoRecharge v0.0.5
By XanDDemoX

Recharges your equipped weapons automatically (if empty) upon entering and leaving combat. 
A single soul gem will be consumed per weapon recharged in the order of worst to best (e.g lesser soul gems will be used before common).

Installation

Extract the "Recharge" folder from the zip:
Place the "Recharge" folder in your addons folder:

"Documents\Elder Scrolls Online\live\Addons"

"Documents\Elder Scrolls Online\liveeu\Addons"

For example:

"Documents\Elder Scrolls Online\live\Addons\Recharge"

"Documents\Elder Scrolls Online\liveeu\Addons\Recharge"

Usage

/rc - Attempts to recharge the currently equipped primary and secondary weapons.
/rc on - Enable automatic equipped weapons recharging.
/rc +
/rc off - Disable automatic equipped weapons recharging.
/rc -
/rc 0-99  - Set the minimum charge percentage

Change Log

Version 0.0.5

  - Enabled setting of a minimum charge percentage.

Version 0.0.4

  - Initial Release