ESOAutoRecharge v1.0.4
By XanDDemoX

Recharges your equipped weapons automatically upon entering and leaving combat. 
A single soul gem will be consumed per weapon recharged in the order of worst to best (e.g lesser soul gems will be used before common).

Installation

Extract the "Recharge" folder from the zip:
Place the "Recharge" folder in your addons folder:

"Documents\Elder Scrolls Online\live\Addons"

"Documents\Elder Scrolls Online\liveeu\Addons"

For example:

"Documents\Elder Scrolls Online\live\Addons\Recharge"

"Documents\Elder Scrolls Online\liveeu\Addons\Recharge"

Usage

/rc - Attempts to recharge the currently equipped primary and secondary weapons.
/rc on - Enable automatic equipped weapons recharging.
/rc +
/rc off - Disable automatic equipped weapons recharging.
/rc -
/rc 0-99  - Set the minimum charge percentage

Change Log

Version 1.0.4

	- Restored original settings variable name

Version 1.0.3

	- Moved Readme and Licence into Recharge folder within zip for users who use Minion. 

Version 1.0.2

	- Disabled master weapon exlcusion

Version 1.0.1

	- Added master weapon exclusion

Version 0.0.6

	- Added string trim to input to remove whitespace before attempting to parse a potentially numeric input

Version 0.0.5

	- Enabled setting of a minimum charge percentage.

Version 0.0.4

	- Initial Release